<?php
require 'conexao.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}
$sala_id = filter_input(INPUT_POST, 'sala_id', FILTER_VALIDATE_INT);
if ($sala_id) {
    $stmt = $conexao->prepare('SELECT luz_ligada FROM salas WHERE sala_id = ?');
    $stmt->bind_param('i', $sala_id);
    $stmt->execute();
    $sala = $stmt->get_result()->fetch_assoc();
    if ($sala) {
        $novo_estado = $sala['luz_ligada'] ? 0 : 1;
        $acao = $novo_estado ? 'Ligou' : 'Desligou';
        $conexao->begin_transaction();
        try {
            $atualizar = $conexao->prepare('UPDATE salas SET luz_ligada = ? WHERE sala_id = ?');
            $atualizar->bind_param('ii', $novo_estado, $sala_id);
            $atualizar->execute();
            $registrar = $conexao->prepare('INSERT INTO registros (sala_id, acao) VALUES (?, ?)');
            $registrar->bind_param('is', $sala_id, $acao);
            $registrar->execute();
            $conexao->commit();
        } catch (Throwable $e) {
            $conexao->rollback();
            die('Não foi possível alterar a luz. Confira as tabelas no banco de dados.');
        }
    }
}
header('Location: index.php');
exit;
