CREATE DATABASE desafio;
USE desafio;

CREATE TABLE usuarios (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL,
    senha VARCHAR(255) NOT NULL
);

CREATE TABLE salas (
    sala_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    turma VARCHAR(50),
    luz_ligada BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE dispositivos (
    dispo_id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(100) NOT NULL,
    sala_id INT NOT NULL,
    FOREIGN KEY (sala_id) REFERENCES salas(sala_id)
);

CREATE TABLE registros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sala_id INT,
    acao VARCHAR(20),
    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sala_id) REFERENCES salas(sala_id)
);
