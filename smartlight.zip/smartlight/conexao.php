<?php
$host = 'localhost:3307';
$usuario = 'root';
$senha = 'admin';
$banco = 'desafio';

$conexao = new mysqli($host, $usuario, $senha, $banco);
if ($conexao->connect_error) {
    die('Não foi possível conectar ao banco de dados. Confira o MySQL do XAMPP e o arquivo conexao.php.');
}
$conexao->set_charset('utf8mb4');

function escapar($texto) {
    return htmlspecialchars((string)$texto, ENT_QUOTES, 'UTF-8');
}
