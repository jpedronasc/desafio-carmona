<?php
require 'conexao.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = trim($_POST['tipo'] ?? '');
    $sala_id = filter_input(INPUT_POST, 'sala_id', FILTER_VALIDATE_INT);
    if ($tipo !== '' && $sala_id) {
        $stmt = $conexao->prepare('INSERT INTO dispositivos (tipo, sala_id) VALUES (?, ?)');
        $stmt->bind_param('si', $tipo, $sala_id);
        $stmt->execute();
    }
    header('Location: dispositivos.php');
    exit;
}
$salas = $conexao->query('SELECT sala_id, nome FROM salas ORDER BY nome');
$dispositivos = $conexao->query('SELECT d.dispo_id, d.tipo, s.nome AS sala FROM dispositivos d JOIN salas s ON s.sala_id = d.sala_id ORDER BY d.dispo_id DESC');
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Dispositivos | SmartLight</title><link rel="stylesheet" href="style.css"></head><body>
<header><h1>💡 SmartLight Escolar</h1></header><nav><a href="index.php">Início</a><a href="salas.php">Salas</a><a href="dispositivos.php">Dispositivos</a><a href="historico.php">Histórico</a></nav>
<main><h2>Cadastrar dispositivo</h2><form method="post" class="cartao formulario"><label>Tipo<input name="tipo" maxlength="100" placeholder="Ex.: Sensor de presença" required></label><label>Sala<select name="sala_id" required><option value="">Escolha uma sala</option><?php while ($s = $salas->fetch_assoc()): ?><option value="<?= (int)$s['sala_id'] ?>"><?= escapar($s['nome']) ?></option><?php endwhile; ?></select></label><button>Cadastrar</button></form>
<h2>Dispositivos cadastrados</h2><div class="cartao"><table><tr><th>ID</th><th>Tipo</th><th>Sala</th></tr><?php while ($d = $dispositivos->fetch_assoc()): ?><tr><td><?= (int)$d['dispo_id'] ?></td><td><?= escapar($d['tipo']) ?></td><td><?= escapar($d['sala']) ?></td></tr><?php endwhile; ?></table></div></main></body></html>
