<?php
require 'conexao.php';
$registros = $conexao->query('SELECT r.id, s.nome AS sala, r.acao, r.data_hora FROM registros r JOIN salas s ON s.sala_id = r.sala_id ORDER BY r.data_hora DESC, r.id DESC LIMIT 100');
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Histórico | SmartLight</title><link rel="stylesheet" href="style.css"></head><body>
<header><h1>💡 SmartLight Escolar</h1></header><nav><a href="index.php">Início</a><a href="salas.php">Salas</a><a href="dispositivos.php">Dispositivos</a><a href="historico.php">Histórico</a></nav>
<main><h2>Histórico de iluminação</h2><div class="cartao"><table><tr><th>Sala</th><th>Ação</th><th>Data e hora</th></tr><?php while ($r = $registros->fetch_assoc()): ?><tr><td><?= escapar($r['sala']) ?></td><td><?= escapar($r['acao']) ?></td><td><?= escapar($r['data_hora']) ?></td></tr><?php endwhile; ?></table></div></main></body></html>
