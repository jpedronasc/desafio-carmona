<?php
require 'conexao.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $turma = trim($_POST['turma'] ?? '');
    if ($nome !== '') {
        $stmt = $conexao->prepare('INSERT INTO salas (nome, turma) VALUES (?, ?)');
        $stmt->bind_param('ss', $nome, $turma);
        $stmt->execute();
    }
    header('Location: salas.php');
    exit;
}
$salas = $conexao->query('SELECT * FROM salas ORDER BY sala_id DESC');
?>
<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Salas | SmartLight</title><link rel="stylesheet" href="style.css"></head><body>
<header><h1>💡 SmartLight Escolar</h1></header><nav><a href="index.php">Início</a><a href="salas.php">Salas</a><a href="dispositivos.php">Dispositivos</a><a href="historico.php">Histórico</a></nav>
<main><h2>Cadastrar sala</h2><form method="post" class="cartao formulario"><label>Nome da sala<input name="nome" maxlength="50" required placeholder="Ex.: Sala 01"></label><label>Turma<input name="turma" maxlength="50" placeholder="Ex.: 3º ano"></label><button>Cadastrar</button></form>
<h2>Salas cadastradas</h2><div class="cartao"><table><tr><th>ID</th><th>Sala</th><th>Turma</th></tr><?php while ($s = $salas->fetch_assoc()): ?><tr><td><?= (int)$s['sala_id'] ?></td><td><?= escapar($s['nome']) ?></td><td><?= escapar($s['turma']) ?></td></tr><?php endwhile; ?></table></div></main></body></html>
