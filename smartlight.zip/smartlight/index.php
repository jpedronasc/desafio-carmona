<?php
require 'conexao.php';
$salas = $conexao->query('SELECT * FROM salas ORDER BY sala_id DESC');
?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SmartLight Escolar</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header><h1>💡 SmartLight Escolar</h1><p>Controle simples de luzes das salas (simulação)</p></header>
<nav><a href="index.php">Início</a><a href="salas.php">Salas</a><a href="dispositivos.php">Dispositivos</a><a href="historico.php">Histórico</a></nav>
<main>
    <h2>Salas de aula</h2>
    <p>Use os botões para simular o controle das luzes.</p>
    <?php if ($salas && $salas->num_rows): ?>
    <div class="grade">
        <?php while ($sala = $salas->fetch_assoc()): ?>
        <section class="cartao">
            <h3><?= escapar($sala['nome']) ?></h3>
            <p>Turma: <?= escapar($sala['turma'] ?: 'Não informada') ?></p>
            <p>Luz: <strong><?= $sala['luz_ligada'] ? 'Acesa 🟡' : 'Apagada ⚫' ?></strong></p>
            <form action="controle.php" method="post">
                <input type="hidden" name="sala_id" value="<?= (int)$sala['sala_id'] ?>">
                <button type="submit" class="<?= $sala['luz_ligada'] ? 'desligar' : '' ?>"><?= $sala['luz_ligada'] ? 'Desligar' : 'Ligar' ?> luz</button>
            </form>
        </section>
        <?php endwhile; ?>
    </div>
    <?php else: ?><p>Nenhuma sala cadastrada. <a href="salas.php">Cadastre a primeira.</a></p><?php endif; ?>
</main>
</body>
</html>
